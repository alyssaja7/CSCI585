train.ipynb:

//revise the sample amount:
nb_train_samples = 2160
nb_validation_samples = 840


//change Dense(1) to Dense(3)
//change the activation function from sigmoid to softmax
//change the loss function from binary_crossentropy to categorical_crossentropy
model.add(Flatten())
model.add(Dense(64))
model.add(Activation('relu'))
model.add(Dropout(0.5))
model.add(Dense(3))
model.add(Activation('softmax'))
model.compile(loss='categorical_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])


//change the class_mode to categorical in the following two places:
train_generator = train_datagen.flow_from_directory(
    train_data_dir,
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode='categorical')

validation_generator = test_datagen.flow_from_directory(
    validation_data_dir,
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode='categorical')





classify.ipynb:
//revise Dense(1) to Dense(3)
//change the activation function from sigmoid to softmax
//change the loss function to categorical_crossentropy
model.add(Flatten())
model.add(Dense(64))
model.add(Activation('relu'))
model.add(Dropout(0.5))
model.add(Dense(3))
model.add(Activation('softmax'))
model.compile(loss='categorical_crossentropy',
              optimizer='rmsprop',
              metrics=['accuracy'])

//change the path to get the bonus1.jpg, bonus2.jpg myPic = '/content/drive/My Drive/Colab Notebooks/cats-vs-dogs/data/live/bonus1.jpg'
myPic2 = '/content/drive/My Drive/Colab Notebooks/cats-vs-dogs/data/live/bonus2.jpg'



//add the following code for the image bonus3.jpg
myPic3 = '/content/drive/My Drive/Colab Notebooks/cats-vs-dogs/data/live/bonus3.jpg'
#myPic2 = '/content/drive/My Drive/Colab Notebooks/cats-vs-dogs/data/live/raccoon.jpg'
test_image3= image.load_img(myPic3, target_size = (img_width, img_height)) 
test_image3 = image.img_to_array(test_image3)
test_image3 = test_image3.reshape(input_shape)
test_image3 = numpy.expand_dims(test_image3, axis = 0)
result = model.predict(test_image3,verbose=0)  
result = numpy.argmax(result)
print(result)

 
//change print(result[0][0]) to the following tow-line code:
result = numpy.argmax(result)
print(result)

